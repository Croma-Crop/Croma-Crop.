<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGRSI - Ficha | Croma Corp</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/global.css">
    <link rel="stylesheet" href="../../css/ficha.css">
    <script src="../../js/ficha.js" defer></script>
</head>
<body data-modulo="ficha">
    <header>
        <h1 id="titulo">Ficha</h1>
            <?php include '../../globales/Header.php'?>
 
    
        

        

    </header>
    <main>
        <section id="contenido">
            <section id="seccion-formulario">
                <h3 class="titulo-seccion">Ficha Docente</h3>
                <form id="fichaForm">

                    <label for="nombreProf">Profesor</label>
                    <input id="nombreProf" type="text" readonly>

                    <label for="fecha_inicio">Fecha</label>
                    <input id="fecha_inicio" type="date" name="fecha" required>

                    <label for="hora_entrada">Hora entrada</label>
                    <input type="time" id="hora_entrada" name="hora_entrada" required>

                    <label for="hora_salida">Hora salida</label>
                    <input type="time" id="hora_salida" name="hora_salida" required>

                    <label for="salon">Salón</label>
                    <select id="salon" name="salon" required>
                        <option value="">--- Seleccionar salón ---</option>
                    </select>

                    <p>Turno:</p>
                    <section class="radio-grupo">
                        <input type="radio" id="matutino" name="turno" value="Matutino">
                        <label for="matutino">Matutino</label>

                        <input type="radio" id="vespertino" name="turno" value="Vespertino">
                        <label for="vespertino">Vespertino</label>

                        <input type="radio" id="nocturno" name="turno" value="Nocturno">
                        <label for="nocturno">Nocturno</label>
                    </section>

                    <button type="submit" id="enviarFicha">Enviar Ficha</button>
                </form>
            </section>

            <section id="seccion-equipos">
                 <h3 class="titulo-seccion">Equipos del salón</h3>
                <p id="avisoEquipos">Seleccioná un salón para ver sus equipos.</p>
                <table id="tablaEquipos" class="oculto">
                    <thead>
                        <tr>
                            <th>Incidencia</th>
                            <th>Equipo</th>
                            <th>Serie</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTablaEquipos"></tbody>
                </table>
            </section>
        </section>
    </main>

    <dialog id="dialogIncidencia">
        <form id="formIncidenciaEquipo">
            <h3>Registrar incidencia</h3>
            <p id="equipoSeleccionado"></p>

            <label for="tipoIncidencia">Tipo de incidencia</label>
            <select id="tipoIncidencia" name="tipoIncidencia" required>
                <option value="">--- Seleccionar ---</option>
                <option value="Computadora">Computadora</option>
                <option value="Televisor">Televisor</option>
                <option value="Periferico">Periferico</option>
                <option value="Otro">Otro</option>
            </select>

            <label for="descripcionIncidencia">¿Cuál es la incidencia?</label>
            <input id="descripcionIncidencia" name="descripcionIncidencia" type="text">

            <div class="dialog-acciones">
                <button type="submit" id="guardarIncidenciaEquipo">Guardar</button>
                <button type="button" id="cancelarIncidenciaEquipo">Cancelar</button>
            </div>
        </form>
    </dialog>

     <?php include '../../globales/Footer.php' ?> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
