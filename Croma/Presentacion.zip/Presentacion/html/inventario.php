<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/global.css">
  <link rel="stylesheet" href="../css/inventario.css">
    <script src="../js/inventario.js" defer></script>
   
</head>
<body data-modulo="inventario">
<header>  
   <h1 id="titulo">Inventario</h1>
 <?php require '../globales/Header.php'?>


</header>
    <article class="contenedor">
    </article>
    <main>
          <section id="contenido">
            <section id="busqueda">
                <input id="inptbusqueda" name="inptbusqueda" placeholder="Buscar">
            </section>
            <article id="seccion-listado">
                <h3 class="titulo-seccion">Inventario de equipos:</h3>
                <ul id="listado">
                </ul>
            </article>

            <article id="seccion-formulario">
                <h3 class="titulo-seccion">Ingresar Nuevo Equipo</h3>
                <form id="formulario-producto">
                    <input name="nombre" type="text" id="nombre" placeholder="Nombre del artículo" required>
                    <input name="marca" type="text" id="marca" placeholder="Marca del articulo" required>
                    <input name="numSerie" type="text" id="numSerie" placeholder="Numero de Serie" required >
                    <input name="estado" type="text" id="estado" placeholder="Ingrese Estado" required>
                    <select name="salon" id="salonInventario" required>
                        <option value="">--- Asignar a un salón ---</option>
                    </select>
                    <button id="submit" type="submit">Guardar Artículo</button>
                </form>
            </article>
        </section>

        <dialog id="dialogHistorial">
            <button id="cerrarHistorial" type="button">Cerrar</button>
            <h3 id="tituloHistorial">Historial de intervenciones</h3>
            <ul id="listaHistorial"></ul>
        </dialog>
    </main>
        <?php include '../globales/Footer.php' ?>   

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>