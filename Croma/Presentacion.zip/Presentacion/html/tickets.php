<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/tickets.css">
    <title>Tickets</title>

    <script>
    const nombreCompleto = "<?= htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']) ?>";
</script>
    <script src="../js/tickets.js" defer></script>
</head>

<body data-modulo="tickets">

    <header>
        <h1 id="titulo">Incidencias y Solicitudes</h1>
        
             <?php include '../globales/Header.php'?>
    
        

        

    </header>

    <main>
        <section id="newsletter">
            <form id="formularioNewsletter">
                <p id="paragraph"><strong>¿Que quiere registrar?</strong></p>

                <div id="campo-documento">
                    <button type="button" id="incidencia">Incidencia</button>
                    <button type="button" id="regSolicitud">Solicitudes</button>
                </div>
            </form>
        </section>
        <section class="contenedor">
            <form id="incforms">
                <h3>Incidencias</h3>

                <label for="fecha">Fecha</label>
                <input id="fecha_inicio" type="date" name="fecha">
                <label for="salon">Salon:</label>
                <select id="salon" name="salon" required>
                    <option value="">--- Seleccionar salón ---</option>
                </select>
                <label for="serie">Equipo del salón:</label>
                <select id="serie" name="serie" required>
                    <option value="">--- Seleccione un salón primero ---</option>
                </select>

                <p>Turno:</p>
                <section class="radio-grupo">
                    <input type="radio" id="matutino" name="turno" value="Matutino">
                    <label for="matutino">Matutino</label>

                    <input type="radio" id="vespertino" name="turno" value="Vespertino">
                    <label for="vespertino">Vespertino</label>

                    <input type="radio" id="nocturno" name="turno" value="Nocturno">
                    <label for="nocturno">Nocturno</label>
                </section>

                <p>Tipo de incidencia</p>
                <select id="tipo" name="tipo" required>
                    <option value="">---Seleccionar---</option>
                    <option value="Computadora">Computadora</option>
                    <option value="Televisor">Televisor</option>
                    <option value="Periferico">Periferico</option>
                    <option value="Otro">Otro</option>
                </select>
                <p>¿Cual es la incidencia?</p>
                <input id="descripcioninc" name="incInput">
                <button id="enviarinc">Enviar Incidencia</button>
                <button type="button" id="volverInc">Volver</button>
            </form>
        </section>

        <section class="contenedorSol">
            <form id="solforms">
                <h3>Solicitudes</h3>
                <p for="tipoSol">¿Tipo de solicitud?</p>
                <select id="tipoSol" name="tipo" required>
                    <option value="">---Seleccionar---</option>
                    <option value="Instalacion de Software">Instalacion de Software</option>
                    <option value="Reserva de Salon">Reserva de Salon</option>
                </select>
                <p for="salonSol">Salón:</p>
                <select id="salonSol" name="salonSol" required>
                    <option value="">--- Seleccionar salón ---</option>
                </select>
                <p>Descripcion de la Solicitud:</p>
                <input type="text" id="descripcionSol">
                <button id="enviarSol" type="button">Enviar Solicitud</button>
                <button type="button" id="volverSol">Volver</button>
            </form>
        </section>
    </main>

    <?php include '../globales/Footer.php' ?> 


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>