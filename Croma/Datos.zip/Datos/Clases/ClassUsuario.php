<?php
class Usuario {
public int $documento;
public String $nombre
public String $apellido
private String $contraseña;
public String $rol;

}





?>